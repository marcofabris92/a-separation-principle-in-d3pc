% closed-loop output cost
function cost = cl_cost_y(opt,y)

cost = norm(opt.yr(:,1:size(y,2))-y,"fro")^2;
    
end
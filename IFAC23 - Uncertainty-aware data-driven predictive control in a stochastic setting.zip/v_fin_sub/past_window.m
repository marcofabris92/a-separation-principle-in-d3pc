function [rho_star,rho_min,rho_max] = past_window(sys,dat,T,IC,labels)

% rho_min computation (rho_min = lag of the system)
rho_min = 1;

% rho_max computation
rho_max = dat.Ndata-T;

% finds rho_star =  optimal lag to reconstruct the past trajectory
% rho_star selection through (corrected) AIC
LJs = length(labels);
rho_star = zeros(LJs,1);
% fprintf('Process completion:\n0%%\n')
% delta = floor(LJs/10);
warning off;
for j_ = 1:LJs
    % if mod(j_,delta) == 0
    %     fprintf([num2str(floor(100*j_/LJs)) '%%\n'])
    % end
    
    j = labels(j_);
    smallest_score = +Inf;
    rho = rho_min;
    N = 1;
    r = [];
    score = [];
    try
        while N > 0
            N = rho_max-rho+1;
            if j == 0
                YUdata = iddata(dat.y(:,1:N)',dat.u(:,1:N)',sys.Ts);
            else
                YUdata = iddata(dat.y_noisy(:,1:N,j)',...
                    dat.u_noisy(:,1:N,j)',sys.Ts);
            end
            arx_model = arx(YUdata,[rho*sys.na rho*sys.nb sys.nk]);
            if strcmp(IC,'FPE')
                score_j = fpe(arx_model);
            else
                score_j = aic(arx_model,IC);
            end
            if score_j < smallest_score
                smallest_score = score_j;
                rho_star(j_) = rho;
            end
            r = [r rho];
            score = [score score_j];
            rho = rho + 1;
        end
    catch
    end
    
%     figure
%     grid on
%     hold on
%     plot(r,score,'k')
%     plot([rho_star(j_) rho_star(j_)],[min(score) max(score)],'r')
%     pause
    
    
end
warning on;

rho_star = round(mean(rho_star));
% fprintf(['Estimated rho_star: ' num2str(rho_star) '\n'])

end
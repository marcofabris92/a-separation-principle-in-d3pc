function [] = approx_valid(gra,clx,e,f,g,h,E,F,G,H,legs,loc,xlab,titl)

figure('position',gra.pos)
hold on
grid on
tt = 0:clx.Tv-1;
tt_ = [0 clx.Tv-1];
hg = plot(tt,g,'r','linewidth',4*gra.lw);
he = plot(tt,e,'g','linewidth',3*gra.lw);
%he = plot(0,0,'g','linewidth',gra.lw);
hf = plot(tt,f,'k','linewidth',2*gra.lw);
hh = plot(tt,h,'b','linewidth',1*gra.lw);
hG = plot(tt_,[G G],'--r','linewidth',2*gra.lw);
hE = plot(tt_,[E E],'--g','linewidth',gra.lw);
%hE = plot(0,0,'--g','linewidth',gra.lw);
hF = plot(tt_,[F F],'--k','linewidth',gra.lw);
hH = plot(tt_,[H H],'--b','linewidth',gra.lw);

h_plots = [he hf hg hh hE hF hG hH];
legend(h_plots,legs,'fontsize',gra.ftsz,'interpreter','latex',...
        'location',loc,'Orientation','horizontal')
    
ax = gca;
ax.TickLabelInterpreter = 'latex';
ax.FontSize = gra.ftsz;
ax.YAxis.Scale = 'log';

xlabel(xlab,'fontsize',gra.ftsz,'interpreter','latex')
title(titl,'fontsize',gra.ftsz,'interpreter','latex')

drawnow
    
end

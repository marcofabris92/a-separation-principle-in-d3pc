function [difference,num,den] = SD_3(clx,prd)

num = norm(clx.sys.HsLam_hat_inv_L33*prd.gamma3)^2;
%num = norm(prd.gamma3)^2;
den = clx.TN*(norm([prd.gamma1; prd.gamma2])^2);
difference = num-den;

end
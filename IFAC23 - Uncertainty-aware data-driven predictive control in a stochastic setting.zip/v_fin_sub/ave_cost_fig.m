function [] = ave_cost_fig(gra,fig,betas,bbar,Jave,Jmin,xlab,ylab,titl,col,...
    my_xticks, my_yticks)
loglog(betas,Jave','color',col,'linewidth',gra.lw)
hold on
grid on
yl = [10^floor(log10(Jmin)-1) 10^floor(log10(Jmin)+3)];
loglog([bbar bbar],[yl(1) Jmin],'k--','linewidth',gra.lw-0.5)
xl = xlim;
loglog([xl(1) bbar],[Jmin Jmin],'k--','linewidth',gra.lw-0.5)
plot([bbar bbar],[Jmin Jmin],'color',col,'marker','.',...
    'markeredgecolor',col*0.65,'markersize',50)
ylim(yl)


ax = fig;
ax.TickLabelInterpreter = 'latex';
ax.FontSize = gra.ftsz;
title(titl,'fontsize',gra.ftsz,'interpreter','latex')
xlabel(xlab,'fontsize',gra.ftsz,'interpreter','latex')
ylabel(ylab,'fontsize',gra.ftsz,'interpreter','latex')

xticks(my_xticks)
yticks(my_yticks)

drawnow

end
    
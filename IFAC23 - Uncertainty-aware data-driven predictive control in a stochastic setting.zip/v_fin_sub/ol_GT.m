function [prd] = ol_GT(clx,dpc,prd)

if clx.opt.is_unconstrained
    prd.gamma2 = pinv(dpc.W_star)*z_star(clx,dpc,prd);
    prd = prd_uy(dpc,prd); 
else
    prd = cvx_sol(clx,dpc,prd,0);
end

end
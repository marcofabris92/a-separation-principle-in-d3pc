function value = z_star(clx,dpc,prd)

value = clx.opt.W12*([prd.ur; prd.yr]-[dpc.L21; dpc.L31]*prd.gamma1);

end
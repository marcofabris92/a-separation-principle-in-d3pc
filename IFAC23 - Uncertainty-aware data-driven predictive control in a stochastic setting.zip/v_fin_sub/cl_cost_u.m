% closed-loop input cost
function cost = cl_cost_u(opt,u)

cost = norm(opt.ur(:,1:size(u,2))-u,"fro")^2;
    
end
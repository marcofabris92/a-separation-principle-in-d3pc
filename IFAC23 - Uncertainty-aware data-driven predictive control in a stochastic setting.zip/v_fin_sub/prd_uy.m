function [prd] = prd_uy(dpc,prd)

prd.u = dpc.L21*prd.gamma1+dpc.L22*prd.gamma2;
prd.y = dpc.L31*prd.gamma1+dpc.L32*prd.gamma2;

end
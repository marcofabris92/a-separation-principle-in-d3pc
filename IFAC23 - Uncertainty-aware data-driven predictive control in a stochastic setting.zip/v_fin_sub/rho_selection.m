function [rho_GT,rho,sys] = ...
    rho_selection(sys,dat,T,IC,rho_search_j,rho_search,NMC)

rho_GT = past_window(sys,dat,T,IC,0);
rho = rho_GT*ones(1,NMC);
sys.rho_star = rho_GT;
if rho_search_j
    parfor j = 1:NMC
        rho(j) = past_window(sys,dat,T,IC,j);
    end
    sys.rho_star = round(mean(rho));
end
if rho_search  % selects common rho_star if requested
    rho = sys.rho_star*ones(1,NMC);
end

end
function [prd] = ol_2(clx,dpc,prd,beta,t)

if isempty(beta)
    prd = tuning(clx,dpc,prd,2,t);
else
    prd.beta = beta;
end

if clx.opt.is_unconstrained
    opt = clx.opt;
    prd.gamma2 = dpc.W_star'*dpc.W_star;
    if prd.beta == Inf
        prd.gamma2 = zeros(opt.mT,1);
    elseif prd.beta == 0
        prd.gamma2 = pinv(prd.gamma2)*dpc.W_star'*z_star(clx,dpc,prd);
    else
        for s = 1:opt.mT
            prd.gamma2(s,s) = prd.gamma2(s,s) + prd.beta;
        end
        prd.gamma2 = (prd.gamma2^-1)*dpc.W_star'*z_star(clx,dpc,prd);
    end
    prd = prd_uy(dpc,prd);
else
    prd = cvx_sol(clx,dpc,prd,2);
end

end


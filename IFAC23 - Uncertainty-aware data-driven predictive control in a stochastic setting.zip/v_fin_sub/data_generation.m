function [sys,dat] = data_generation(sys,dat,opt,sigma_u,SNR_dB,NMC)

x0 = zeros(sys.n,1);
u_long = randn(sys.m,max(10*dat.Ndata*sys.p,1e6));   

%% 1) adjusting sys.Q, sys.R, sys.S; computing Kalman paramters 
if sys.flag_noise
    fprintf('Adjusting SNR ...\n\n')
    
    % sqrt of noise covariance matrix
    if isempty(sys.K)
        rk_V = rank([sys.Q sys.S; sys.S' sys.R]);
        [U_V12,S_V12,~] = svd([sys.Q sys.S; sys.S' sys.R]);
        sys.V12 = U_V12(:,1:rk_V)*sqrtm(S_V12(1:rk_V,1:rk_V));
    else
        sys.V12 = [sys.K; eye(sys.p)]*sqrtm(sys.R);
    end

    % getting SNR ratio
    y_stoch_comp_long = dynamics(sys,x0,zeros(size(u_long)),[],[]);
    sys.flag_noise = 0;
    y_det_long = dynamics(sys,x0,u_long,[],[]);
    sys.flag_noise = 1;
    snr_0 = 1+sample_var(y_det_long)/sample_var(y_stoch_comp_long);
    snr_target = 10^(SNR_dB/10);
    snr_ratio = (snr_0-1)/(snr_target-1);

    % rescaling state and output noise covariances
    sys.Q = snr_ratio * sys.Q; % adjusted Q
    sys.R = snr_ratio * sys.R; % adjusted R
    sys.S = snr_ratio * sys.S; % adjusted S

    % Kalman update matrices
    sys.Z = sys.S*(sys.R^-1);
    sys.F = sys.A-sys.Z*sys.C;
    sys.B_bar = sys.B-sys.Z*sys.D;
    sys.Q_tilde = sys.Q-sys.Z*sys.S';
    if ~isempty(sys.K)
        sys.Q_tilde = zeros(sys.n);
    end
    
    % sqrt of noise covariance matrix
    if isempty(sys.K)
        rk_V = rank([sys.Q sys.S; sys.S' sys.R]);
        [U_V12,S_V12,~] = svd([sys.Q sys.S; sys.S' sys.R]);
        sys.V12 = U_V12(:,1:rk_V)*sqrtm(S_V12(1:rk_V,1:rk_V));
    else
        sys.V12 = [sys.K; eye(sys.p)]*sqrtm(sys.R);
    end
    
    % Kalman stationary matrices (gain and innovation variance)
    [sys.P_inf,~,sys.K_inf] = dare(sys.F',sys.C',sys.Q_tilde,sys.R);
    sys.K_inf = sys.K_inf';
    sys.Lambda_inf = sys.C*sys.P_inf*sys.C'+sys.R;
    
    % innovation form matrices
    if isempty(sys.K)
        sys.K = sys.K_inf+sys.Z;
        sys.Lambda = sys.Lambda_inf;
    else
        sys.Lambda = sys.R;
    end
    
    % variance of the stochastic part of the total cost
    Lam12 = sqrtm(sys.Lambda);
    sys.stoch_cost_Var = trace(Lam12'*opt.Q*Lam12);
    
    % computation of Hs
    sys.Hs = eye(opt.pT);
    for low_diag = 0:opt.T-2
        ii = (1:sys.p)+low_diag*sys.p;
        new_entry = sys.Gamma(ii,:)*sys.K;
        for col = low_diag:opt.T-2
            ii = (1:sys.p)+(col+1)*sys.p;
            jj = (1:sys.m)+(col-low_diag)*sys.m;
            sys.Hs(ii,jj) = new_entry;
        end
    end
    
    % inverse and normalized Hs
    sys.HsLam_inv = pinv(sys.Hs*kron(opt.I_T,sqrtm(sys.Lambda)));
    
    % state of the predictor and prediction error variance
    sys.x_ini__ini_1 = zeros(sys.n,1);
    sys.P_ini__ini_1 = dlyap(sys.F,sys.Q);
    if norm(sys.Q,"fro") == 0
        sys.x_ini__ini_1 = 0e0*randn(sys.n,1);
        sys.P_ini__ini_1 = 2*eye(sys.n);
    end
    
    % initial state to generate data
    rk_P = rank(sys.P_ini__ini_1);
    [U_P12,S_P12,~] = svd(sys.P_ini__ini_1);
    sys.P12 = U_P12(:,1:rk_P)*sqrtm(S_P12(1:rk_P,1:rk_P));
    x0 = sys.P12*randn(size(sys.P12,2),1);
    
    % initial state of the underlying problem
    sys.x0 = sys.P12*randn(size(sys.P12,2),1);

end
    
%% 2) initializing dat.u and dat.y (noiseless dataset)
if 0
    HLP = filter_design(1,1/pi);
    my_filter = tf(HLP.Numerator,[1 zeros(1,length(HLP.Numerator)-1)],sys.Ts);
    l_tr = round(1.2*length(HLP.Numerator));
    dat.u = lsim(my_filter,u_long(:,1:dat.Ndata+l_tr))';
    dat.u = dat.u(:,end-dat.Ndata+1:end);
else
    dat.u = u_long(:,1:dat.Ndata);
end
flag_noise_copy = sys.flag_noise;
sys.flag_noise = 0;
dat.y = dynamics(sys,x0,dat.u,[],[]);
sys.flag_noise = flag_noise_copy;

%% 3) getting training dataset (NMC noisy datasets)
dat.u_noisy = zeros(sys.m,dat.Ndata,NMC);
dat.y_noisy = zeros(sys.p,dat.Ndata,NMC);
for j = 1:NMC
    dat.u_noisy(:,:,j) = sigma_u*randn(sys.m,dat.Ndata);
    dat.y_noisy(:,:,j) = dynamics(sys,x0,dat.u_noisy(:,:,j),[],[]);
end


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [V_hat] = sample_var(x)

% rows of x: features
% columns of x: observations >> features

V_hat = 0;
mu = mean(x,2);
T_long = size(x,2);
parfor t = 1:T_long
    V_hat = V_hat + norm(x(:,t)-mu)^2;
end
V_hat = V_hat / (T_long-size(x,1));

end



function [vx,vy] = sys_noise(sys,T)

if sys.flag_noise
    vx = sys.V12*randn(size(sys.V12,2),T);
    vy = vx(sys.n+1:end,:);
    vx = vx(1:sys.n,:);
else
    vx = zeros(sys.n,T);
    vy = zeros(sys.p,T);
end

end
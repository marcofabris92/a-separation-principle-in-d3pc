function [sol_GT] = get_GT(clx,actual_dpc)

clx.sys.flag_noise = 0;

% Hankel matrices
dpc.Up = actual_dpc.UpGT;
dpc.Uf = actual_dpc.UfGT;
dpc.Yp = actual_dpc.YpGT;
dpc.Yf = actual_dpc.YfGT;

% dpc_ini parameters
dpc.Tini = actual_dpc.Tini;
dpc.vec_uini = actual_dpc.vec_uini;
dpc.vec_yini = actual_dpc.vec_yini;
dpc.xini = actual_dpc.xini;

% LQ decomposition (for data... but data are noise-free in GT)
dpc.p1 = actual_dpc.p1;
dpc.p2 = actual_dpc.p2;
dpc.p3 = actual_dpc.p3;
dpc = lqdec_part(dpc,clx.opt,1);

% ground truth solutions:  (noise free data, clean output)
sol_GT = cl(clx,dpc,0,0,[]);
check = norm(sol_GT.yf_hat-sol_GT.yf,"fro"); % this value must be 0

fprintf('************************************\n')
fprintf('GROUND TRUTH NOISE-FREE ORACLE\n')
if 0 && check > 1e-10 && clx.opt.is_unconstrained
    error('Oracle is computed incorrectly.')
end
fprintf(['Noise-free oracle check: ' num2str(check) '\n'])
fprintf(['sol_GT.J = ' num2str(sol_GT.J) '\n'])
fprintf('************************************\n')
        
        
end
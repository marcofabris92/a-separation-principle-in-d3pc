function [sol] = cl(clx,dpc,type,KF_comp,beta)

%% COMMON INITIALIZATION
% unpacking variables
sys = clx.sys;
opt = clx.opt;
Tv = clx.Tv;
ddpc_approach = (type == 0 || type == 2 || type == 3);
KF_approach = (type == 1);
mm = 1:sys.m;
pp = 1:sys.p;

% solution initialization
sol.uf = zeros(opt.mT,Tv);
sol.yf_hat = zeros(opt.pT,Tv);
sol.yf = zeros(opt.pT,Tv);

%% SPECIFIC INITIALIZATION
% initialization of the past trajectories
xini = dpc.xini;                       
vx_true = [];
vy_true = [];
if ddpc_approach
    uini = dpc.vec_uini;
    yini = dpc.vec_yini;
    sol.n2gamma12 = zeros(1,Tv);
end
if KF_approach
    prd.x_t__t_1 = sys.x_ini__ini_1;    % x0|-1
    prd.P_t__t_1 = sys.P_ini__ini_1;    % P0|-1
end
if ddpc_approach && KF_comp
    sol.yf_hat_star = zeros(opt.pT,Tv);
    prd_KF_comp.x_t__t_1 = sys.x_ini__ini_1;    % x0|-1
    prd_KF_comp.P_t__t_1 = sys.P_ini__ini_1;    % P0|-1
end

% initializing interesting quantities depending on "type"
eb = isempty(beta);
switch type
    case 0
        sys.flag_noise = 0;
    case 1
    case 2
        if eb
            sol.beta2_tuned = zeros(1,Tv);
            sol.actual_SD2 = zeros(1,Tv);
        end
    case 3
        sol.gamma3 = zeros(opt.pT,Tv);
        if eb
            sol.beta3_tuned = zeros(1,Tv);
            sol.actual_SD3 = zeros(1,Tv);
        end
end

% main closed-loop
for t = 1:Tv
    %% SOLVING
    prd.ur = opt.vec_ur((t-1)*sys.m+1 : (t+opt.T-1)*sys.m);
    prd.yr = opt.vec_yr((t-1)*sys.p+1 : (t+opt.T-1)*sys.p);
    if ddpc_approach
        prd.gamma1 = dpc.pinv_L11*[uini; yini];
    end
    prd = ol(clx,dpc,xini,type,prd,beta,t);
    if sys.flag_noise
        vx_true = sys.vx(:,t:t+opt.T-1);
        vy_true = sys.vy(:,t:t+opt.T-1);
    end
    u_true = reshape(prd.u,[sys.m,opt.T]);
    [y_true,x_true] = dynamics(sys,xini,u_true,vx_true,vy_true);
    %% COMMON ASSIGNMENT
    % assigning solutions
    sol.uf(:,t) = prd.u;
    sol.yf_hat(:,t) = prd.y;
    sol.yf(:,t) = reshape(y_true,[opt.pT,1]);
    %% SPECIFIC ASSIGNMENT
    % assigning interesting quantities depending on "type"
    if ddpc_approach
        sol.n2gamma12(t) = norm([prd.gamma1; prd.gamma2])^2;
        if KF_comp
            prd_KF_comp = ol_KF(clx,xini,prd_KF_comp,prd.u,t);
            sol.yf_hat_star(:,t) = prd_KF_comp.y;
        end
    end
    switch type
        case 0
        case 1
        case 2
            if eb
                sol.beta2_tuned(t) = prd.beta;
                sol.actual_SD2(t) = SD_2(clx,prd);
            end
        case 3
            sol.gamma3(:,t) = prd.gamma3;
            %% plots of y for beta3 (tuned)
            if eb
                sol.beta3_tuned(t) = prd.beta;
                sol.actual_SD3(t) = SD_3(clx,prd);
                
                if clx.gra.showIteratedFigs
                    prd.y
                    figure('position',[100 100 1200 800])
                    grid on
                    hold on
                    tt = (t-1:t+opt.T-2)';
                    hyr = plot(tt,prd.yr,'k','linewidth',3);
                    hy1 = plot(tt,sol.yf_hat_star(:,t),'r','linewidth',2);
                    hyfhat = plot(tt,sol.yf_hat(:,t),'b','linewidth',1.5);
                    hyf = plot(tt,sol.yf(:,t),'--b','linewidth',1.5);
                    hplots = [hyr hy1 hyfhat hyf];
                    names = {'$y_{r}(t)$','$\hat{y}_{f}^{\star}(t)$',...
                        '$\hat{y}_{f}(t)$','$y_{f}(t)$ (true but not realized)'};
                    legend(hplots,names,'interpreter','latex','fontsize',20)
                    title(['t = ' num2str(t-1)])
                    drawnow
                    pause
                    close
                end
                
            end
    end
    %% UPDATE
    xini = x_true(:,2);
    if ddpc_approach
        uini = [uini(sys.m+1:end); prd.u(mm)];
        yini = [yini(sys.p+1:end); y_true(:,1)];
    end
end

% computation of the closed-loop performance
sol.Ju = cl_cost_u(opt,sol.uf(mm,:))/Tv;
sol.Jy = cl_cost_y(opt,sol.yf(pp,:))/(opt.yrTvnorm2);
sol.J = cl_cost(opt,sol.uf(mm,:),sol.yf(pp,:))/Tv;
sol.Jd = (sol.J-sys.stoch_cost_Var)/opt.yrQTvnorm2;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [prd] = ol(clx,dpc,xini,type,prd,beta,t)

prd.beta = 0;

switch type
    case 0
        prd = ol_GT(clx,dpc,prd);
    case 1
        prd = ol_KF(clx,xini,prd,[],t);
    case 2
        prd = ol_2(clx,dpc,prd,beta,t);
    case 3
        prd = ol_3(clx,dpc,prd,beta,t);
end

end


% finds best beta(2 or 3) by minimizing |SD(2 or 3)| at each feedback step
function [prd] = tuning(clx,dpc,prd,type,t)

switch type
    case 2
        beta_ = clx.beta2_;
    case 3
        beta_ = clx.beta3_;
end

best_abs_diff = +Inf;
best_beta = NaN;
Lpts = length(beta_);
diffs = zeros(1,Lpts);
num = zeros(1,Lpts);
den = zeros(1,Lpts);
sign_num_R = 0;
sign_den_R = 0;
sign_num_L = 0;
sign_den_L = 0;
intersection_found = 0;
i_best = 0;
is_last_beta_finite = (beta_(end) < Inf);

i = Lpts;
while ~intersection_found && i > 0
    switch type
        case 2
            [diffs(i),num(i),den(i)] =...
                SD_2(clx,ol_2(clx,dpc,prd,beta_(i),t));
        case 3
            [diffs(i),num(i),den(i)] =...
                SD_3(clx,ol_3(clx,dpc,prd,beta_(i),t));
    end
  
    if num(i) > den(i)
        sign_num_L = 1;
        sign_den_L = -1;
    elseif num(i) < den(i)
        sign_num_L = -1;
        sign_den_L = 1;
    else
        best_beta = beta_(i);
        intersection_found = 1;
    end
    
    if i < Lpts && ~intersection_found &&...
            sign_num_L*sign_num_R == -1 && sign_den_L*sign_den_R == -1
        del = [num(i+1)-den(i+1) num(i)-den(i)]';
        best_beta = ([beta_(i) -beta_(i+1)]*del)/([1 -1]*del); 
        intersection_found = 1;
    end
    
    if ~intersection_found && (i < Lpts || is_last_beta_finite)
        if num(i) > den(i)
            sign_num_R = 1;
            sign_den_R = -1;
        elseif num(i) < den(i)
            sign_num_R = -1;
            sign_den_R = 1;
        end
    end
   
    abs_diff_i = abs(diffs(i));
    if abs_diff_i < best_abs_diff
        best_abs_diff = abs_diff_i;
        i_best = i;
    end
    
    i = i - 1;
end

if ~intersection_found
    best_beta = beta_(i_best);
end

if clx.LP
    best_beta = ((t-1)*prd.beta+best_beta)/t;
end
prd.beta = best_beta;



% % figure
% % semilogx(beta_,num,'k','linewidth',2)
% % hold on
% % grid on
% % semilogx(beta_,den,'r','linewidth',1)
% % title(['t = ' num2str(t) ', best beta' num2str(type) ' = ' ...
% %     num2str(best_beta) ', i best = ' num2str(i_best)])
% % pause
% % close 

end


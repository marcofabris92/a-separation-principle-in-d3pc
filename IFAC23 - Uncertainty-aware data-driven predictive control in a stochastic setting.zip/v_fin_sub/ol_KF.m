function [prd] = ol_KF(clx,x_t,prd,u,t)

opt = clx.opt;
sys = clx.sys;
if ~isempty(u)
    prd.u = u;
end

%% computing the optimal uf, yf for the Kalman-based oracle,
% or assigning uf = u for a KF comparison

if opt.is_unconstrained
    prd.y = sys.Gamma*prd.x_t__t_1;
    if isempty(u)
        prd.u = opt.Upsilon_u*prd.ur + opt.Upsilon_y*(prd.yr-prd.y);
    end
    prd.y = prd.y + sys.Hd*prd.u;
else
    if isempty(u)
        prd = cvx_sol(clx,[],prd,1);
    else
        prd = cvx_sol(clx,[],prd,5);
    end
end

%% getting the new KF-based prediction for state x(t+1)

u_t = prd.u(1:sys.m);
y_t = sys.C*x_t+sys.D*u_t+sys.vy(:,t);
L_t = prd.P_t__t_1*sys.C'*((sys.C*prd.P_t__t_1*sys.C'+sys.R)^-1);
I_L_tC = sys.In-L_t*sys.C;

x_filt_t = prd.x_t__t_1 + L_t*(y_t-sys.C*prd.x_t__t_1-sys.D*u_t);
P_filt_t = I_L_tC*prd.P_t__t_1*I_L_tC' + L_t*sys.R*L_t';

prd.x_t__t_1 = sys.F*x_filt_t + sys.Z*y_t + sys.B_bar*u_t;
prd.P_t__t_1 = sys.F*P_filt_t*sys.F' + sys.Q_tilde;



end





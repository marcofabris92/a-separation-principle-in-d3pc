function [dpc] = lqdec_part(dpc,opt,type)

switch type
    case 0 % noise-free ground truth
        [~,L] = lqdec([dpc.UpGT; dpc.YpGT; dpc.UfGT; dpc.YfGT]);
        dpc.pinv_LGT11 = pinv(L(dpc.p1,dpc.p1));
        dpc.LGT21 = L(dpc.p2,dpc.p1);
        dpc.LGT22 = L(dpc.p2,dpc.p2);
        dpc.LGT31 = L(dpc.p3,dpc.p1);
        dpc.LGT32 = L(dpc.p3,dpc.p2);
        dpc.LGT33 = L(dpc.p3,dpc.p3);
    case 1 % noisy gamma-DDPC
        [~,L] = lqdec([dpc.Up; dpc.Yp; dpc.Uf; dpc.Yf]);
        dpc.pinv_L11 = pinv(L(dpc.p1,dpc.p1));
        dpc.L21 = L(dpc.p2,dpc.p1);
        dpc.L22 = L(dpc.p2,dpc.p2);
        dpc.L31 = L(dpc.p3,dpc.p1);
        dpc.L32 = L(dpc.p3,dpc.p2);
        dpc.L33 = L(dpc.p3,dpc.p3);
        % computing useful stuff to be used later
        dpc.pinv_L33 = pinv(dpc.L33);
        dpc.W_star = opt.W12*[dpc.L22; dpc.L32];
end

end

% LQ decomposition
function [Q,L] = lqdec(Q)
    [Q,L] = qr(Q',0);
    L = L';
    Q = Q';
end



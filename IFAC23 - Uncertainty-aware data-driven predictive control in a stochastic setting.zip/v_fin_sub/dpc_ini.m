function [dpc,sys] = dpc_ini(sys,dat,T,rho_star)
    
% initial stuff
dpc.Tini = rho_star;                % prefix-trajectory length
uini = zeros(sys.m,dpc.Tini);                           % uini
dpc.vec_uini = reshape(uini,[sys.m*dpc.Tini,1]);
[yini,xini] = dynamics(sys,sys.x0,uini,[],[]);          % yini
dpc.vec_yini = reshape(yini,[sys.m*dpc.Tini,1]);
dpc.xini = xini(:,end);                                 % xini

% exploiting initial information to get a better initialization of the KF
for t = 1:dpc.Tini
    L_t = sys.P_ini__ini_1*sys.C'*...
        ((sys.C*sys.P_ini__ini_1*sys.C'+sys.R)^-1);
    I_L_tC = sys.In-L_t*sys.C;

    x_filt_t = sys.x_ini__ini_1 +...
        L_t*(yini(:,t)-sys.C*sys.x_ini__ini_1-sys.D*uini(:,t));  
    P_filt_t = I_L_tC*sys.P_ini__ini_1*I_L_tC' + L_t*sys.R*L_t';

    sys.x_ini__ini_1 = sys.F*x_filt_t + sys.Z*yini(:,t) + sys.B_bar*uini(:,t);
    sys.P_ini__ini_1 = sys.F*P_filt_t*sys.F' + sys.Q_tilde;
end

% Hankel size
dpc.TTini = dpc.Tini+T;              % # of Hankel rows
dpc.N = dat.Ndata-dpc.TTini+1;       % # of Hankel columns

% partitioning sizes for the LQ decomposition
dpc.p1 = 1 : (sys.m+sys.p)*dpc.Tini;
dpc.p2 = dpc.p1(end)+1 : dpc.p1(end)+sys.m*T;
dpc.p3 = dpc.p2(end)+1 : dpc.p2(end)+sys.p*T;

    
end
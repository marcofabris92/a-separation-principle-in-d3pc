function [prd] = ol_3(clx,dpc,prd,beta,t)

if isempty(beta)
    prd = tuning(clx,dpc,prd,3,t);
else
    prd.beta = beta;
end
        

if clx.opt.is_unconstrained
    opt = clx.opt;
    W_star = [dpc.W_star opt.W12*[zeros(opt.mT,opt.pT); dpc.L33]];
    gamma23 = W_star'*W_star;
    if prd.beta == Inf
        W_star = gamma23(1:opt.mT,1:opt.mT)^-1;
        gamma23 = zeros(opt.mT+opt.pT,1);
        gamma23(1:opt.mT) = W_star*dpc.W_star'*z_star(clx,dpc,prd);
    elseif prd.beta == 0
        gamma23 = pinv(gamma23)*W_star'*z_star(clx,dpc,prd);
    else
        for s = (1:opt.pT)+opt.mT
            gamma23(s,s) = gamma23(s,s) + prd.beta;
        end
        gamma23 = (gamma23^-1)*W_star'*z_star(clx,dpc,prd);
    end
    prd.gamma2 = gamma23(1:opt.mT);
    prd.gamma3 = gamma23(opt.mT+1:end);    
    prd = prd_uy(dpc,prd);
else
    prd = cvx_sol(clx,dpc,prd,3);
end

end


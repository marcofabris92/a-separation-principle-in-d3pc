function [difference,num,den] = SD_2(clx,prd)

num = norm(clx.sys.HsLam_hat_inv*(reshape(prd.y,[clx.opt.pT,1])-prd.yr))^2;
%num = norm(clx.L33_inv*(reshape(prd.y,[clx.opt.pT,1])-prd.yr))^2;
den = clx.TN*(norm([prd.gamma1; prd.gamma2])^2);
difference = num-den;

end
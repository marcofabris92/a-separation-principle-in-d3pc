function [Hp,Hf,H] = Hankel(dpc,series)

H = Hankel_construction(series,dpc.TTini,dpc.N)/sqrt(dpc.N);
d_s = size(series,1);
Hp = H(1:d_s*dpc.Tini,:);
Hf = H(1+d_s*dpc.Tini:end,:);
    
end

% builds a Hankel matrix given a time series
function H = Hankel_construction(series,N_rows,N_cols) 

d_s = size(series,1);
H = zeros(N_rows*d_s,N_cols);
for i = 1:N_rows
    ii = (1:d_s)+(i-1)*d_s;
    for j = 1:N_cols
        H(ii,j) = series(:,i+j-1);
    end
end
    
end
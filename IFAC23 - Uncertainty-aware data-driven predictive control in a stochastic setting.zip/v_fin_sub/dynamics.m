function [y,x,vy,vx] = dynamics(sys,xini,u,vx,vy)

T = size(u,2);
x = zeros(sys.n,T+1);
x(:,1) = xini;
y = zeros(sys.p,T);
if isempty(vx) && ~isempty(vy)
    vx = sys_noise(sys,T);
end
if ~isempty(vx) && isempty(vy)
    [~,vy] = sys_noise(sys,T);
end
if isempty(vx) && isempty(vy)
    [vx,vy] = sys_noise(sys,T);
end
for t = 1:T
    y(:,t) = sys.C*x(:,t)+sys.D*u(:,t)+sys.flag_noise*vy(:,t);
    x(:,t+1) = sys.A*x(:,t)+sys.B*u(:,t)+sys.flag_noise*vx(:,t);
end

end












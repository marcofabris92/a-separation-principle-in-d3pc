function [prd] = cvx_sol(clx,dpc,prd,type)

global cvx_sol_time cvx_sol_counter
cvx_sol_counter = cvx_sol_counter + 1;
cvx_sol_time_tic = tic;

% cost functional
Ucost = "+(prd.ur-uf)'*opt.TR*(prd.ur-uf)";
Ycost = "+(prd.yr-yf_hat)'*opt.TQ*(prd.yr-yf_hat)";
fnct = strcat(Ucost,Ycost);

% the two regularization added to the cost functional
reg2 = "+prd.beta*gamma2'*gamma2";
reg3 = "+prd.beta*gamma3'*gamma3";

% ddpc constraints
data_uf = "uf == dpc.L21*prd.gamma1+dpc.L22*gamma2";
data_yf_hat = "yf_hat == dpc.L31*prd.gamma1+dpc.L32*gamma2";
data_yf_hat33 = "+dpc.L33*gamma3";

% KF-based oracle constraint
kf_io = "yf_hat == prd.y+clx.sys.Hd*uf";

opt = clx.opt;
switch type
    case 0
        cvx_begin quiet
        variables gamma2(opt.mT) uf(opt.mT) yf_hat(opt.pT)
        minimize(eval(fnct))
        subject to
        eval(data_uf);
        eval(data_yf_hat);
        eval(opt.set_cnstr)
        cvx_end
        prd.gamma2 = gamma2;
    case 1
        cvx_begin quiet
        variables uf(opt.mT) yf_hat(opt.pT)
        minimize(eval(fnct))
        subject to
        eval(kf_io);
        eval(opt.set_cnstr)
        cvx_end
    case 2
        cvx_begin quiet
        variables gamma2(opt.mT) uf(opt.mT) yf_hat(opt.pT)
        minimize(eval(strcat(fnct,reg2)))
        subject to
        eval(data_uf);
        eval(data_yf_hat);
        eval(opt.set_cnstr)
        cvx_end
        prd.gamma2 = gamma2;
    case 3
        cvx_begin quiet
        variables gamma2(opt.mT) gamma3(opt.pT) uf(opt.mT) yf_hat(opt.pT)
        minimize(eval(strcat(fnct,reg3)))
        subject to
        eval(data_uf);
        eval(strcat(data_yf_hat,data_yf_hat33));
        eval(opt.set_cnstr)
        cvx_end
        prd.gamma2 = gamma2;
        prd.gamma3 = gamma3;
    case 5
        uf = prd.u;
        cvx_begin quiet
        variables yf_hat(opt.pT)
        minimize(eval(fnct))
        subject to
        eval(kf_io);
        eval(opt.set_cnstr)
        cvx_end
end

% cvx_slvitr
% cvx_status

prd.u = uf;
prd.y = yf_hat;

cvx_sol_time = cvx_sol_time + toc(cvx_sol_time_tic);

end
clear all
close all
clc

%% execution time measurements
global main_time cvx_sol_time cvx_sol_counter
cvx_sol_time = 0;
cvx_sol_counter = 0;
main_time = tic;

%% Blade options
bld.exe = 0;
bld.load = 0;
if bld.exe
    bld.load = 0;
end

%% graphic options
savefig_flag = 1;
nfigs = 19;
gra.lw = 2;
gra.ftsz = 20;
gra.verbose = 1;
gra.showIteratedFigs = 0;
gra.KF = 0;
gra.show_ys_beta3_tuned = 0;
fig_counter = 1-nfigs;
if bld.exe
    gra.showIteratedFigs = 0;
    gra.KF = 0;
    gra.show_ys_beta3_tuned = 0;
    savefig_flag = 0;
end


%% setup
NMC = 1e1;                      % # of Monte Carlo samples
NMC_inner = 1*1e0;              % # of Monte Carlo samples (inner)
dat.Ndata = 250;             	% input/output series length (original 250)
sys.flag_noise = 1;           	% 1: sets noise in the model
sys.q = 0*1e-2;                 % state variance (noise in the model)
sys.r = 1*1e-2;                 % output variance (noise in the model)
                                
opt.Wu = 1e-2;               	% input weight for cost (original 1e-2)
opt.Wy = 2*1e3;                 % output weight for cost (original 2*1e3)
opt.T = 20;                    	% prediction horizon (original 20)
opt.I_T = eye(opt.T);           % identity matrix of dimension T
opt.O_T = zeros(opt.T);         % zero matrix of dimension T
opt.set_cnstr = [...            % list of set constraints for uf and yf_hat
    'norm(uf,Inf) <= 2;',...
    ];  
opt.U = 2;
opt.is_unconstrained = 1; %isempty(opt.set_cnstr);
cvx_solver sedumi % SDPT3 %
cvx_precision low % medium % default % high % best

Lpts = 2*10^2;                    % # of points in the beta grids
clx.beta2_ = logspace(0,4,Lpts); % beta2 grid (1,7)
clx.beta3_ = logspace(-4,0,Lpts); % beta3 grid (-4,2)
% Lpts = Lpts + 2;
% clx.beta2_ = [0 clx.beta2_ +Inf]; % +Inf
% clx.beta3_ = [0 clx.beta3_ +Inf]; % +Inf
clx.LP = 0;                     % low pass tuning heuristics
clx.Tv = 50;                  	% number of feedback steps (original 50)
clx.gra = gra;                  % saving graphics options                  

sigma_u = 1;                    % std input training data
rho_search = 0;                 % 1: sets rho via AICc once for all
rho_search_j = 1;               % 1: sets rho via AICc at each
                                %    Monte Carlo experiment

% models
% model = 0 <=> Breschi - Chiuso - Formentin
% model = 1 <=> Dorfler - Coulson - Markovsky (white noise output error)
% model = 2 <=> Berberich
% model = 3 <=> Dorfler - Coulson - Markovsky (colored noise inn. form)
models = [1];

% information criteria: 'AICc', 'nAIC', 'AIC', 'BIC', 'FPE'
ICs = {'AICc'}; 


%% model loop
for model = models
    if ~bld.load
    %% model selection:
    
    [sys,opt] = model_selection(sys,clx,opt,model); 
    clx.opt = opt;
    end
    
    % SNR Var(y)/Var(noise) (in dB): list to be tried
    switch model
        case 1
            SNRs_dB = 13; %[8 18 28];
        case 3
            SNRs_dB = [8 18 28];
    end
    % white noise SNR: 
    % instability -> 13, no need to reg -> 33, medium -> 23 ?
    % colored noised SNR: 
    % instability -> 3, no need to reg -> 33, medium -> 13
    
    
for snr_target_dB = SNRs_dB
    fig_counter = fig_counter + nfigs;
    if ~bld.load
        
    fprintf('////////////////////////////////////\n')
    fprintf(['Selected SNR: ' num2str(snr_target_dB) ' dB\n\n'])
    
    %% data generation
    % 1) adjusting sys.Q, sys.R, sys.S; computing Kalman paramters 
    % 2) initializing dat.u and dat.y (noiseless dataset)
    % 3) getting training dataset (NMC noisy datasets)
    [sys,dat] = data_generation(sys,dat,opt,sigma_u,snr_target_dB,NMC);
    
    end
    
for ic = 1:length(ICs)
    
    if ~bld.load
    
    % selection of the length of the past window (rho)
    IC = ICs{ic}; % chosen information criterion
    fprintf(['Estimating rho (' IC ') ...\n'])
    [rho_GT,rho,sys] = ...
        rho_selection(sys,dat,opt.T,IC,rho_search_j,rho_search,NMC);
    fprintf('Values of rho found:')
    rho_GT
    rho
    
    
    % Noise-free ground-truth solution
    copy_flag_noise = sys.flag_noise;
    sys.flag_noise = 0;
    [dpc,sys] = dpc_ini(sys,dat,opt.T,rho_GT);
    sys.flag_noise = copy_flag_noise;
    [dpc.UpGT,dpc.UfGT] = Hankel(dpc,dat.u);
    [dpc.YpGT,dpc.YfGT] = Hankel(dpc,dat.y); 
    dpc = lqdec_part(dpc,opt,0);             
    clx.TN = opt.T/dpc.N;
    clx.sys = sys;
    sol_GT = get_GT(clx,dpc);
    
    % error('Checkpoint: noise-free oracle\n')
    
    % MC loop initialization
    
    % KF oracle initialization
    J_KF = zeros(1,NMC);
    J_KF_u = zeros(1,NMC);
    J_KF_y = zeros(1,NMC);
    J_KF_d = zeros(1,NMC);
    
    u1 = zeros(opt.mT,clx.Tv,NMC);
    y1 = zeros(opt.pT,clx.Tv,NMC);
    y1_TR = zeros(opt.pT,clx.Tv,NMC);
    
    % beta 2 bar initialization
    J2_grid = zeros(Lpts,NMC);
    J2_ave = zeros(Lpts,1);
    J2_bar = zeros(1,NMC);
    Ju2_bar = zeros(1,NMC);
    Jy2_bar = zeros(1,NMC);
    Jd2_bar = zeros(1,NMC);
    beta2_bar = zeros(1,NMC);
    
    u2_bar = zeros(opt.mT,clx.Tv,NMC);
    y2_bar = zeros(opt.pT,clx.Tv,NMC);
    y2_bar_TR = zeros(opt.pT,clx.Tv,NMC);
    y2_bar_KF = zeros(opt.pT,clx.Tv,NMC);
    n2_gamma12_2_bar = zeros(clx.Tv,NMC);
    
    ef_2_bar = zeros(clx.Tv,NMC);
    ef_hat_2_bar = zeros(clx.Tv,NMC);
    T_N_gamma12_2_bar = zeros(clx.Tv,NMC);
    e_track_hat_bar = zeros(clx.Tv,NMC);
    
    % beta 3 bar initialization
    J3_grid = zeros(Lpts,NMC);
    J3_ave = zeros(Lpts,1);
    J3_bar = zeros(1,NMC);
    Ju3_bar = zeros(1,NMC);
    Jy3_bar = zeros(1,NMC);
    Jd3_bar = zeros(1,NMC);
    beta3_bar = zeros(1,NMC);
    
    u3_bar = zeros(opt.mT,clx.Tv,NMC);
    y3_bar = zeros(opt.pT,clx.Tv,NMC);
    y3_bar_TR = zeros(opt.pT,clx.Tv,NMC);
    y3_bar_KF = zeros(opt.pT,clx.Tv,NMC);
    n2_gamma12_3_bar = zeros(clx.Tv,NMC);
    gamma3_bar = zeros(opt.pT,clx.Tv,NMC);
    
    ef_3_bar = zeros(clx.Tv,NMC);
    ef_hat_3_bar = zeros(clx.Tv,NMC);
    T_N_gamma12_3_bar = zeros(clx.Tv,NMC);
    e_n2gamma3_bar = zeros(clx.Tv,NMC);
    
    % beta 2 tuned initialization
    Ju2_tuned = zeros(1,NMC);
    Jy2_tuned = zeros(1,NMC);
    Jd2_tuned = zeros(1,NMC);
    J2_tuned = zeros(1,NMC);   
    
    beta2_tuned = zeros(clx.Tv,NMC);
    SD2abs_actual = zeros(clx.Tv,NMC);
    
    u2_tuned = zeros(opt.mT,clx.Tv,NMC);
    y2_tuned = zeros(opt.pT,clx.Tv,NMC);
    y2_tuned_TR = zeros(opt.pT,clx.Tv,NMC);
    y2_tuned_KF = zeros(opt.pT,clx.Tv,NMC);
    n2_gamma12_2_tuned = zeros(clx.Tv,NMC);
    
    ef_2_tuned = zeros(clx.Tv,NMC);
    ef_hat_2_tuned = zeros(clx.Tv,NMC);
    T_N_gamma12_2_tuned = zeros(clx.Tv,NMC);
    e_track_hat_tuned = zeros(clx.Tv,NMC);
    
    % beta 3 tuned initialization
    Ju3_tuned = zeros(1,NMC);
    Jy3_tuned = zeros(1,NMC);
    Jd3_tuned = zeros(1,NMC);
    J3_tuned = zeros(1,NMC);    
    
    beta3_tuned = zeros(clx.Tv,NMC);
    SD3abs_actual = zeros(clx.Tv,NMC);
    
    u3_tuned = zeros(opt.mT,clx.Tv,NMC);
    y3_tuned = zeros(opt.pT,clx.Tv,NMC);
    y3_tuned_TR = zeros(opt.pT,clx.Tv,NMC);
    y3_tuned_KF = zeros(opt.pT,clx.Tv,NMC);
    n2_gamma12_3_tuned = zeros(clx.Tv,NMC);
    gamma3_tuned = zeros(opt.pT,clx.Tv,NMC);
    
    ef_3_tuned = zeros(clx.Tv,NMC);
    ef_hat_3_tuned = zeros(clx.Tv,NMC);
    T_N_gamma12_3_tuned = zeros(clx.Tv,NMC);
    e_n2gamma3_tuned = zeros(clx.Tv,NMC);
    
    
    % main loop
    % bar = minimum of the average
    % tilde = average of the minima
     
    [dpc,sys] = dpc_ini(sys,dat,opt.T,sys.rho_star);
    clx.TN = opt.T/dpc.N;
    
    for j = 1:NMC
        
        visual = (mod(j,100) == 0);
        if  gra.verbose && visual
            fprintf('\n__________________________\n')
            fprintf(['\nj = ' num2str(j) '\n'])
        end
         
        % resets dpc at each MC experiment if requested
        if rho_search_j
            [dpc,sys] = dpc_ini(sys,dat,opt.T,rho(j));
            clx.TN = opt.T/dpc.N;
        end
         
        % noisy Hankel matrices
        [dpc.Up,dpc.Uf] = Hankel(dpc,dat.u_noisy(:,:,j));
        [dpc.Yp,dpc.Yf] = Hankel(dpc,dat.y_noisy(:,:,j));
        
        % LQ decomposition (noisy data)
        dpc = lqdec_part(dpc,opt,1);
        clx.L33_inv = dpc.pinv_L33;
        
        % estimation of (Hs*Lambda^(1/2))^-1 and related matrices
        sys = HsLam_estimation(sys,dat,opt,rho(j),dat.Ndata,j);
        sys.HsLam_hat_inv_L33 = sys.HsLam_hat_inv*dpc.L33;
        check_Hs = norm(sys.Hs-sys.Hs_hat,"fro")
        
        
        % grid optimization
        if gra.verbose && visual
            fprintf('Optimization on grid ...\n')
        end
        
        for j_inner = 1:NMC_inner
            
            % j_inner-th noise realization
            [sys.vx,sys.vy] = sys_noise(sys,sys.TvT);
            clx.sys = sys;
            
            % i-th grid optimization
            for i = 1:Lpts
                if mod(i,1000) == 0
                    fprintf(['i = ' num2str(i) '\n'])
                end
                sol = cl(clx,dpc,2,0,clx.beta2_(i));
                J2_grid(i,j) = J2_grid(i,j) + sol.J;
                sol = cl(clx,dpc,3,0,clx.beta3_(i));
                J3_grid(i,j) = J3_grid(i,j) + sol.J;
            end
            
        end
        
        J2_grid(:,j) = J2_grid(:,j) / NMC_inner;
        J3_grid(:,j) = J3_grid(:,j) / NMC_inner;
        J2_ave = J2_ave + J2_grid(:,j);
        J3_ave = J3_ave + J3_grid(:,j);
        [~,i2_bar_j] = min(J2_grid(:,j));
        [~,i3_bar_j] = min(J3_grid(:,j));
        beta2_bar(j) = clx.beta2_(i2_bar_j);
        beta3_bar(j) = clx.beta3_(i3_bar_j);
        
        % j-th noise realization
        [sys.vx,sys.vy] = sys_noise(sys,sys.TvT);
        clx.sys = sys;
         
        % KF-based oracle
        if  gra.verbose && visual
            fprintf('j-th KF-based oracle\n')
        end
        sol = get_KF(clx,dpc);
        J_KF(j) = sol.J;
        J_KF_u(j) = sol.Ju;
        J_KF_y(j) = sol.Jy;
        J_KF_d(j) = sol.Jd;
        u1(:,:,j) = sol.uf;
        y1(:,:,j) = sol.yf_hat;
        y1_TR(:,:,j) = sol.yf;
        
        % applying beta2 bar already found
        fprintf('beta2 chosen a-posteriori\n')
        sol = cl(clx,dpc,2,1,beta2_bar(j));
        J2_bar(j) = sol.J;
        Ju2_bar(j) = sol.Ju;
        Jy2_bar(j) = sol.Jy;
        Jd2_bar(j) = sol.Jd;
        u2_bar(:,:,j) = sol.uf;
        y2_bar(:,:,j) = sol.yf_hat;
        y2_bar_TR(:,:,j) = sol.yf;
        y2_bar_KF(:,:,j) = sol.yf_hat_star;
        n2_gamma12_2_bar(:,j) = sol.n2gamma12;
        for t = 1:clx.Tv
            yr_t = opt.vec_yr((t-1)*sys.p+1 : (t+opt.T-1)*sys.p);
            yf_tilde_t = y2_bar(:,t,j)-y2_bar_KF(:,t,j);
            ef_2_bar(t,j) = norm(sys.HsLam_inv*yf_tilde_t)^2;           % e
            ef_hat_2_bar(t,j) = norm(sys.HsLam_hat_inv*yf_tilde_t)^2;   % f
            T_N_gamma12_2_bar(t,j) = clx.TN*n2_gamma12_2_bar(t,j);      % g
            e_track_hat_bar(t,j) = ...
                norm(sys.HsLam_hat_inv*(y3_bar(:,t,j)-yr_t))^2;         % h
        end
        fprintf(['    J2_j bar = ' num2str(sol.J) '\n'])
        
        % applying beta3 bar already found
        fprintf('beta3 chosen a-posteriori\n')
        sol = cl(clx,dpc,3,1,beta3_bar(j));
        J3_bar(j) = sol.J;
        Ju3_bar(j) = sol.Ju;
        Jy3_bar(j) = sol.Jy;
        Jd3_bar(j) = sol.Jd;
        u3_bar(:,:,j) = sol.uf;
        y3_bar(:,:,j) = sol.yf_hat;
        y3_bar_TR(:,:,j) = sol.yf;
        y3_bar_KF(:,:,j) = sol.yf_hat_star;
        n2_gamma12_3_bar(:,j) = sol.n2gamma12;
        gamma3_bar(:,:,j) = sol.gamma3;
        for t = 1:clx.Tv
            yf_tilde_t = y3_bar(:,t,j)-y3_bar_KF(:,t,j);
            ef_3_bar(t,j) = norm(sys.HsLam_inv*yf_tilde_t)^2;           % e
            ef_hat_3_bar(t,j) = norm(sys.HsLam_hat_inv*yf_tilde_t)^2;   % f
            T_N_gamma12_3_bar(t,j) = clx.TN*n2_gamma12_3_bar(t,j);      % g
            e_n2gamma3_bar(t,j) = ...
                norm(sys.HsLam_hat_inv_L33*gamma3_bar(:,t,j))^2;        % h
        end
        fprintf(['    J3_j bar = ' num2str(sol.J) '\n'])
        
        % beta2 tuning strategy
        fprintf('Tuning of beta2\n')
        sol = cl(clx,dpc,2,1,[]);
        J2_tuned(j) = sol.J;
        Ju2_tuned(j) = sol.Ju;
        Jy2_tuned(j) = sol.Jy;
        Jd2_tuned(j) = sol.Jd;
        u2_tuned(:,:,j) = sol.uf;
        y2_tuned(:,:,j) = sol.yf_hat;
        y2_tuned_TR(:,:,j) = sol.yf;
        y2_tuned_KF(:,:,j) = sol.yf_hat_star;
        n2_gamma12_2_tuned(:,j) = sol.n2gamma12;
        beta2_tuned(:,j) = sol.beta2_tuned;
        SD2abs_actual(:,j) = abs(sol.actual_SD2);
        for t = 1:clx.Tv
            yr_t = opt.vec_yr((t-1)*sys.p+1 : (t+opt.T-1)*sys.p);
            yf_tilde_t = y2_tuned(:,t,j)-y2_tuned_KF(:,t,j);
            ef_2_tuned(t,j) = norm(sys.HsLam_inv*yf_tilde_t)^2;         % e
            ef_hat_2_tuned(t,j) = norm(sys.HsLam_hat_inv*yf_tilde_t)^2; % f
            T_N_gamma12_2_tuned(t,j) = clx.TN*n2_gamma12_2_tuned(t,j);  % g
            e_track_hat_tuned(t,j) = ...
                norm(sys.HsLam_hat_inv*(y2_tuned(:,t,j)-yr_t))^2;       % h
        end
        fprintf(['    J2_j tuned = ' num2str(sol.J) '\n'])
        
        % beta3 tuning strategy
        fprintf('Tuning of beta3\n')
        sol = cl(clx,dpc,3,1,[]);
        J3_tuned(j) = sol.J;
        Ju3_tuned(j) = sol.Ju;
        Jy3_tuned(j) = sol.Jy;
        Jd3_tuned(j) = sol.Jd;
        u3_tuned(:,:,j) = sol.uf;
        y3_tuned(:,:,j) = sol.yf_hat;
        y3_tuned_TR(:,:,j) = sol.yf;
        y3_tuned_KF(:,:,j) = sol.yf_hat_star;
        n2_gamma12_3_tuned(:,j) = sol.n2gamma12;
        gamma3_tuned(:,:,j) = sol.gamma3;
        beta3_tuned(:,j) = sol.beta3_tuned;
        SD3abs_actual(:,j) = abs(sol.actual_SD3);
        for t = 1:clx.Tv
            yf_tilde_t = y3_tuned(:,t,j)-y3_tuned_KF(:,t,j);
            ef_3_tuned(t,j) = norm(sys.HsLam_inv*yf_tilde_t)^2;         % e
            ef_hat_3_tuned(t,j) = norm(sys.HsLam_hat_inv*yf_tilde_t)^2; % f
            T_N_gamma12_3_tuned(t,j) = clx.TN*n2_gamma12_3_tuned(t,j);  % g
            e_n2gamma3_tuned(t,j) = ...
                norm(sys.HsLam_hat_inv_L33*gamma3_tuned(:,t,j))^2;      % h
        end
        fprintf(['    J3_j tuned = ' num2str(sol.J) '\n'])

    end
     
    
    % MC averaging
    % error('Checkpoint: MC averaging to be done')
    fprintf('\n__________________________\n')
    fprintf('MC averaging...\n\n')
    
    % beta bar found and related costs
    J2_ave = J2_ave / NMC;
    J3_ave = J3_ave / NMC;
    [J2_min,i2_min_bar] = min(J2_ave);
    [J3_min,i3_min_bar] = min(J3_ave);
    best_beta2_bar = clx.beta2_(i2_min_bar);
    best_beta3_bar = clx.beta3_(i3_min_bar);
    MC_beta2_bar = median(beta2_bar); % median
    MC_beta3_bar = median(beta3_bar); % median
%     MC_beta2_bar = 0;
%     MC_beta3_bar = 0;
%     counter_b2b = 0;
%     counter_b3b = 0;
%     for j = 1:NMC
%         if beta2_bar(j) < +Inf
%             counter_b2b = counter_b2b + 1;
%             MC_beta2_bar = MC_beta2_bar + beta2_bar(j);
%         end
%         if beta3_bar(j) < +Inf
%             counter_b3b = counter_b3b + 1;
%             MC_beta3_bar = MC_beta3_bar + beta3_bar(j);
%         end
%     end
%     MC_beta2_bar = MC_beta2_bar / counter_b2b;
%     MC_beta3_bar = MC_beta3_bar / counter_b3b;
    
    fprintf('\n**************************\n')
    fprintf('Found betas on grid:\n')
    fprintf(['best_beta2_bar = ' num2str(best_beta2_bar) '\n'])
    fprintf(['best_beta3_bar = ' num2str(best_beta3_bar) '\n'])
    fprintf(['MC_beta2_bar = ' num2str(MC_beta2_bar) '\n'])
    fprintf(['MC_beta3_bar = ' num2str(MC_beta3_bar) '\n'])
    fprintf('**************************\n')

    MC_J_KF = mean(J_KF,Ls(J_KF));
    MC_J2_grid = mean(J2_grid,Ls(J2_grid));
    MC_J3_grid = mean(J3_grid,Ls(J3_grid));
    if norm(MC_J2_grid-J2_ave,"fro") > 1e-10 || ...
            norm(MC_J3_grid-J3_ave,"fro") > 1e-10
        error('Incorrect averaging.\n')
    end
    MC_J2_bar = mean(J2_bar);
    MC_J3_bar = mean(J3_bar);
    
    % tuned stuff
    MC_J2_tuned = mean(J2_tuned,Ls(J2_tuned));          % scalar
    MC_J3_tuned = mean(J3_tuned,Ls(J3_tuned));          % scalar
    MC_SD2_actual = mean(SD2abs_actual,Ls(SD2abs_actual));    % Tv
    mean_MC_SD2_actual = mean(MC_SD2_actual,Ls(MC_SD2_actual));    % scalar
    MC_beta2_tuned = mean(beta2_tuned,Ls(beta2_tuned)); % Tv
    mean_MC_beta2_tuned = mean(MC_beta2_tuned,Ls(MC_beta2_tuned)); % scalar
    MC_beta3_tuned = mean(beta3_tuned,Ls(beta3_tuned)); % Tv
    mean_MC_beta3_tuned = mean(MC_beta3_tuned,Ls(MC_beta3_tuned)); % scalar
    MC_SD3_actual = mean(SD3abs_actual,Ls(SD3abs_actual));    % Tv
    mean_MC_SD3_actual = mean(MC_SD3_actual,Ls(MC_SD3_actual));    % scalar
    
    % validation of the approximations to select betas while tuning
    e_2_bar = mean(ef_2_bar,Ls(ef_2_bar));
    E_2_bar = mean(e_2_bar);
    f_2_bar = mean(ef_hat_2_bar,Ls(ef_hat_2_bar));
    F_2_bar = mean(f_2_bar);
    g_2_bar = mean(T_N_gamma12_2_bar,Ls(T_N_gamma12_2_bar));
    G_2_bar = mean(g_2_bar);
    h_2_bar = mean(e_track_hat_bar,Ls(e_track_hat_bar));
    H_2_bar = mean(h_2_bar);
    
    e_3_bar = mean(ef_3_bar,Ls(ef_3_bar));
    E_3_bar = mean(e_3_bar);
    f_3_bar = mean(ef_hat_3_bar,Ls(ef_hat_3_bar));
    F_3_bar = mean(f_3_bar);
    g_3_bar = mean(T_N_gamma12_3_bar,Ls(T_N_gamma12_3_bar));
    G_3_bar = mean(g_3_bar);
    h_3_bar = mean(e_n2gamma3_bar,Ls(e_n2gamma3_bar));
    H_3_bar = mean(h_3_bar);
    
    e_2_tuned = mean(ef_2_tuned,Ls(ef_2_tuned));
    E_2_tuned = mean(e_2_tuned);
    f_2_tuned = mean(ef_hat_2_tuned,Ls(ef_hat_2_tuned));
    F_2_tuned = mean(f_2_tuned);
    g_2_tuned = mean(T_N_gamma12_2_tuned,Ls(T_N_gamma12_2_tuned));
    G_2_tuned = mean(g_2_tuned);
    h_2_tuned = mean(e_track_hat_tuned,Ls(e_track_hat_tuned));
    H_2_tuned = mean(h_2_tuned);
    
    e_3_tuned = mean(ef_3_tuned,Ls(ef_3_tuned));
    E_3_tuned = mean(e_3_tuned);
    f_3_tuned = mean(ef_hat_3_tuned,Ls(ef_hat_3_tuned));
    F_3_tuned = mean(f_3_tuned);
    g_3_tuned = mean(T_N_gamma12_3_tuned,Ls(T_N_gamma12_3_tuned));
    G_3_tuned = mean(g_3_tuned);
    h_3_tuned = mean(e_n2gamma3_tuned,Ls(e_n2gamma3_tuned));
    H_3_tuned = mean(h_3_tuned);
    
    % error('Checkpoint: MC averaging done')
    
    %% showing final numerical results
    fprintf('\n**************************\n')
    fprintf('Final results:\n')
    fprintf('________\n')
    fprintf(['J_GT = ' num2str(sol_GT.J) '\n'])
    fprintf(['MC_J_KF = ' num2str(MC_J_KF) '\n'])
    fprintf(['MC J2 bar = ' num2str(MC_J2_bar) '\n'])
    fprintf(['MC J3 bar = ' num2str(MC_J3_bar) '\n'])
    fprintf(['MC J2 tuned = ' num2str(MC_J2_tuned) '\n'])
    fprintf(['MC J3 tuned = ' num2str(MC_J3_tuned) '\n'])
    fprintf('________\n')
    % display(mean_MC_SD2_actual)
    % display(mean_MC_SD3_actual)
    % fprintf('________\n')
    % display(mean_MC_beta2_tuned)
    % display(mean_MC_beta3_tuned)
    fprintf('**************************\n')
    
    end
    % error('Checkpoint: MC final results')
    
    %% Producing plots
    if bld.exe
        filename = ['model' num2str(model) '_SNR' num2str(snr_target_dB) '.mat'];
        save(filename)
    end
    if savefig_flag
    if bld.load
        filename = ['model' num2str(model) '_SNR' num2str(snr_target_dB) '.mat'];
        load(filename)
        bld.exe = 0;
        bld.load = 1;
        savefig_flag = 1;
    end
    fprintf('\n____________________________\n')
    fprintf('Producing plots ...\n')
    fprintf('____________________________\n')
    
    xempty = [];
    for j = 1:NMC
        xempty = strcat(xempty,'-');
    end
    xempty = xempty';

    % my_boxplot(x,y,constants,legs,xlab,ylab,titl,Ylog)
    
    % All final CL performances
    gra.ftsz = 34;
    xcell = {'$J_{KF}$', '$\bar{J}_2$', '$\bar{J}_3$', '$\hat{J}_2$', '$\hat{J}_3$'};
    gra.pos = [100 100 900 700];
    my_boxplot(gra,xcell,[J_KF; J2_bar; J3_bar; J2_tuned; J3_tuned],...
        [],... % sol_GT.J
        {},... % '$J_{GT}$'
        'northeast',...
        '','','Performance',0,0);
    
    % All final CL control costs
    xcell = {'$J_{u,KF}$', '$\bar{J}_{u,2}$', '$\bar{J}_{u,3}$', '$\hat{J}_{u,2}$', '$\hat{J}_{u,3}$'};
    my_boxplot(gra,xcell,[J_KF_u; Ju2_bar; Ju3_bar; Ju2_tuned; Ju3_tuned],...
        [],...
        {},...
        '',...
        '','','Control effort',0,0);
    
    % All final CL relative tracking errors (normalized by yr)
    xcell = {'$J_{y,KF}$', '$\bar{J}_{y,2}$', '$\bar{J}_{y,3}$', '$\hat{J}_{y,2}$', '$\hat{J}_{y,3}$'};
    my_boxplot(gra,xcell,[J_KF_y; Jy2_bar; Jy3_bar; Jy2_tuned; Jy3_tuned],...
        [],...
        {},...
        '',...
        '','','Relative tracking error',0,0);
    
    % All final CL tracking errors (deterministic part)
    xcell = {'$J_{d,KF}$', '$\bar{J}_{d,2}$', '$\bar{J}_{d,3}$', '$\hat{J}_{d,2}$', '$\hat{J}_{d,3}$'};
    my_boxplot(gra,xcell,[J_KF_d; Jd2_bar; Jd3_bar; Jd2_tuned; Jd3_tuned],...
        [],...
        {},...
        '',...
        '','','Closed-loop average cost (deterministic part)',0,0);
    
    % Distributions of beta_bar
    xcell = {'$\bar{\beta}_{2}$', '$\bar{\beta}_{3}$'};
    my_boxplot(gra,xcell,[beta2_bar; beta3_bar],...
        [],...
        {},...
        '',...
        '','','Distributions of $\bar{\beta}_{2,3}$',1,0);
    
    % threshold boxplots
    gra.pos = [100 100 1200 300]; 
    stride = 1:clx.Tv;
    % boxplots of tuned optimal beta2
    my_boxplot(gra,stride-1,beta2_tuned(stride,:),...
        [MC_beta2_bar],...
        {'$\bar{\beta}_{2}$ (median)'},... % (median)
        'southeast',...
        '$t~[s]$','$\hat{\beta}_{2}(t)$',...
        ['Tuning of $\hat{\beta}_{2}(t)$ over the closed-loop'],1,1);
    
    % scaling boxplots
    gra.pos = [100 100 1200 300];
    stride = 1:clx.Tv;
    % boxplots of tuned optimal beta3
    my_boxplot(gra,stride,beta3_tuned(stride,:),...
        [MC_beta3_bar],...
        {'$\bar{\beta}_{3}$ (median)'},... % (median)
        'northeast',...
        '$t~[s]$','$\hat{\beta}_{3}(t)$',...
        ['Tuning of $\hat{\beta}_{3}(t)$ over the closed-loop'],1,1);
    
    % tuning approximation for beta2
    gra.pos = [100 100 1200 600];
    stride = 1:clx.Tv;
    % boxplots of SD2s
    my_boxplot(gra,stride-1,SD2abs_actual(stride,:),...
        [0],...
        {'desired value = 0'},...
        'northeast',...
        '$t~[s]$','',...
        ['Selection strategy for beta2 over the closed-loop'],1,1);
    
    % tuning approximation for beta3
    gra.pos = [100 100 1200 600];
    stride = 1:clx.Tv;
    % boxplots of SD3s
    my_boxplot(gra,stride-1,SD3abs_actual(stride,:),...
        [0],...
        {'desired value = 0'},...
        'northeast',...
        '$t~[s]$','',...
        ['Selection strategy for beta3 over the closed-loop'],1,1);
    
    % beta2 and beta3 comparison for minimum CL average costs
    gra.pos = [0 100 800 700];
    figure('position',gra.pos)
    fig = subplot(2,1,1);
    xlab = '$\beta_2$';
    ylab = '$J_{AV,2}(\beta_2)$';
    titl = ''; %'Average closed-loop performance vs $\beta_2$';
    ave_cost_fig(gra,fig,clx.beta2_,best_beta2_bar,J2_ave,J2_min,...
        xlab,ylab,titl,[1 0 0],[10^0 10 10^2 10^3 10^4],[10^1 10^2 10^3 10^4 10^5]);
    fig = subplot(2,1,2);
    xlab = '$\beta_3$';
    ylab = '$J_{AV,3}(\beta_3)$';
    titl = ''; %'Average closed-loop performance vs $\beta_3$';
    ave_cost_fig(gra,fig,clx.beta3_,best_beta3_bar,J3_ave,J3_min,...
        xlab,ylab,titl,[0 0 1],[10^-4 10^-3 10^-2 10^-1 10^0],[10^1 10^2 10^3 10^4 10^5]);
    
    % tracking errors
    gra.ftsz = 30;
    gra.pos = [100 100 600 600];
    my_col = [128,0,128]/255;
    pp = 1:sys.p;
    track_err_fig(gra,clx,NMC,y1_TR(pp,:,:),'$t~[s]$','$y_{KF}(t)$','',my_col)
    my_col = [1 0 0];
    track_err_fig(gra,clx,NMC,y2_bar_TR(pp,:,:),'$t~[s]$','$\bar{y}_2(t)$','',my_col)
    track_err_fig(gra,clx,NMC,y2_tuned_TR(pp,:,:),'$t~[s]$','$\hat{y}_2(t)$','',my_col)
    my_col = [0 0 1];
    track_err_fig(gra,clx,NMC,y3_bar_TR(pp,:,:),'$t~[s]$','$\bar{y}_3(t)$','',my_col)
    track_err_fig(gra,clx,NMC,y3_tuned_TR(pp,:,:),'$t~[s]$','$\hat{y}_3(t)$','',my_col)
    
    % validation of the approximations to select betas while tuning
    gra.ftsz = 30;
    gra.pos = [100 100 900 600];
    approx_valid(gra,clx,e_2_bar,f_2_bar,g_2_bar,h_2_bar,...
        E_2_bar,F_2_bar,G_2_bar,H_2_bar,...
        {'$\bar{e}_{2}$','$\bar{f}_{2}$','$\bar{g}_{2}$','$\bar{h}_{2}$',...
        '$\bar{E}_{2}$','$\bar{F}_{2}$','$\bar{G}_{2}$','$\bar{H}_{2}$'},...
        'northeast',...
        '$t~[s]$',...
        'Validation of (25) for $\bar{\beta}_2$')
    approx_valid(gra,clx,e_3_bar,f_3_bar,g_3_bar,h_3_bar,...
        E_3_bar,F_3_bar,G_3_bar,H_3_bar,...
        {'$\bar{e}_{3}$','$\bar{f}_{3}$','$\bar{g}_{3}$','$\bar{h}_{3}$',...
        '$\bar{E}_{3}$','$\bar{F}_{3}$','$\bar{G}_{3}$','$\bar{H}_{3}$'},...
        'northeast',...
        '$t~[s]$',...
        'Validation of (27) for $\bar{\beta}_3$')
    approx_valid(gra,clx,e_2_tuned,f_2_tuned,g_2_tuned,h_2_tuned,...
        E_2_tuned,F_2_tuned,G_2_tuned,H_2_tuned,...
        {'$\hat{e}_{2}$','$\hat{f}_{2}$','$\hat{g}_{2}$','$\hat{h}_{2}$',...
        '$\hat{E}_{2}$','$\hat{F}_{2}$','$\hat{G}_{2}$','$\hat{H}_{2}$'},...
        'northeast',...
        '$t~[s]$',...
        'Validation of (25) for $\hat{\beta}_2$')
    approx_valid(gra,clx,e_3_tuned,f_3_tuned,g_3_tuned,h_3_tuned,...
        E_3_tuned,F_3_tuned,G_3_tuned,H_3_tuned,...
        {'$\hat{e}_{3}$','$\hat{f}_{3}$','$\hat{g}_{3}$','$\hat{h}_{3}$',...
        '$\hat{E}_{3}$','$\hat{F}_{3}$','$\hat{G}_{3}$','$\hat{H}_{3}$'},...
        'northeast',...
        '$t~[s]$',...
        'Validation of (27) for $\hat{\beta}_3$')
    
    end
    
end

if 0*savefig_flag
    fig_name = ['model' num2str(model) '_SNR' num2str(snr_target_dB) '.fig'];
    savefig(fig_counter:fig_counter+nfigs-1,fig_name);
end

end
end

%% End of program
fprintf('DONE\n')
main_time = toc(main_time);
cvx_sol_share = cvx_sol_time/main_time;
cvx_sol_self_time = cvx_sol_time/cvx_sol_counter;
main_time
cvx_sol_time
cvx_sol_share
cvx_sol_counter
cvx_sol_self_time

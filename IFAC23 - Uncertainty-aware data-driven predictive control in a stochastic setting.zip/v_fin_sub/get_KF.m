function [sol_KF] = get_KF(clx,dpc)

sol_KF = cl(clx,dpc,1,0,[]);
check = norm(sol_KF.yf_hat-sol_KF.yf,"fro");

if clx.gra.KF
    fprintf('************************************\n')
    fprintf('KALMAN-BASED NOISY ORACLE\n')
    fprintf(['Noisy oracle check: ' num2str(check) '\n'])
    fprintf(['sol_KF.J = ' num2str(sol_KF.J) '\n'])
    fprintf('************************************\n')
end

end
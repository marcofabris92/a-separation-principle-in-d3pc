function [sys] = HsLam_estimation(sys,dat,opt,rho,N,j)


est_model = arx(iddata(dat.y_noisy(:,1:N,j)',...
    dat.u_noisy(:,1:N,j)'),[rho*sys.na rho*sys.nb sys.nk]);
sys.HsLam_hat_inv = zeros(opt.pT);
for t = 0:min(opt.T-1,rho)
    for r = 1:sys.p
        for c = 1:sys.p
            if sys.p > 1
                a_rc_t = est_model.a{r,c}(t+1);
            else
                a_rc_t = est_model.a(t+1);
            end
            for i = t+1:opt.T
                ii = (i-1)*sys.p+r;
                jj = (i-1-t)*sys.p+c;
                sys.HsLam_hat_inv(ii,jj) = a_rc_t;
            end
        end
    end
end
sys.Hs_hat = pinv(sys.HsLam_hat_inv);
sys.HsLam_hat_inv = pinv(kron(opt.I_T,sqrtm(est_model.noisevariance))) ...
    * sys.HsLam_hat_inv;

end
% returns the number of dimensions of a tensor
function n_dimensions = Ls(tensor)

n_dimensions = 0;
if ~isempty(tensor)
    n_dimensions = length(size(tensor));
end

end